To learn more about usage example, documentation and demo visit:

http://jquery-howto.blogspot.com/2009/04/jquery-twitter-api-plugin.html


See output-demo.js file for details of returned json object.

Demo: http://custom-drupal.com/jquery-demo/jtwitter/